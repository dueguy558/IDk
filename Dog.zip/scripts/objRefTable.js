const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.TiledBg,
		C3.Behaviors.scrollto,
		C3.Plugins.Text,
		C3.Plugins.Button,
		C3.Plugins.System.Cnds.Every,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.System.Cnds.CompareVar
	];
};
self.C3_JsPropNameTable = [
	{TiledBackground: 0},
	{ScrollTo: 0},
	{TiledBackground2: 0},
	{TiledBackground3: 0},
	{Text: 0},
	{Text2: 0},
	{Text3: 0},
	{Text4: 0},
	{Button: 0},
	{Button2: 0},
	{DoggoThang: 0}
];

self.InstanceType = {
	TiledBackground: class extends self.ITiledBackgroundInstance {},
	TiledBackground2: class extends self.ITiledBackgroundInstance {},
	TiledBackground3: class extends self.ITiledBackgroundInstance {},
	Text: class extends self.ITextInstance {},
	Text2: class extends self.ITextInstance {},
	Text3: class extends self.ITextInstance {},
	Text4: class extends self.ITextInstance {},
	Button: class extends self.IButtonInstance {},
	Button2: class extends self.IButtonInstance {}
}